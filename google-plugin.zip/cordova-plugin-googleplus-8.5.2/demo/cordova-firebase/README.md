1) Create a project with the Cordova copy over the index.html
2) Download the firebase lib and place it into the js/ folder (in the example we use <script src="js/firebase-3.6.4.js"></script>)
3) Make sure you have a projet in firebase and you have the config info
            - Copy your info in the correct places in index.html (web client id and firebase config)
4) For the basic demo you need in the db a key named "songs/" inside you need elements like songs { "song-id" { title: "song-title" }, ... }

Enjoy!

